const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "*" } });

app.use(cors());
app.use(bodyParser.json());

let carLocation = { lat: 28.6139, lng: 77.2090 };

// Update location endpoint
app.post("/update-location", (req, res) => {
  const { lat, lng } = req.body;
  carLocation = { lat, lng };
  console.log("Location updated:", carLocation);
  io.emit("location-update", carLocation);
  res.json({ status: "success", location: carLocation });
});

// SOS endpoint
app.post("/sos", (req, res) => {
  console.log("🚨 SOS triggered at", carLocation);
  io.emit("sos-alert", carLocation);
  res.json({ status: "SOS sent", location: carLocation });
});

// Serve frontend
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

io.on("connection", (socket) => {
  console.log("Client connected");
  socket.emit("location-update", carLocation);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
